from django.conf import settings
from django.shortcuts import render, redirect
import pandas as pd
from .models import UserRegistrationModel
from django.contrib import messages


def UserRegisterActions(request):
    if request.method == 'POST':
        user = UserRegistrationModel(
            name=request.POST['name'],
            loginid=request.POST['loginid'],
            password=request.POST['password'],
            mobile=request.POST['mobile'],
            email=request.POST['email'],
            locality=request.POST['locality'],
            address=request.POST['address'],
            city=request.POST['city'],
            state=request.POST['state'],
            status='waiting'
        )
        user.save()
        messages.success(request, "Registration successful!")
    return render(request, 'UserRegistrations.html')


def UserLoginCheck(request):
    if request.method == "POST":
        loginid = request.POST.get('loginid')
        pswd = request.POST.get('pswd')
        print("Login ID = ", loginid, ' Password = ', pswd)
        try:
            check = UserRegistrationModel.objects.get(loginid=loginid, password=pswd)
            status = check.status
            print('Status is = ', status)
            if status == "activated":
                request.session['id'] = check.id
                request.session['loggeduser'] = check.name
                request.session['loginid'] = loginid
                request.session['email'] = check.email
                data = {'loginid': loginid}
                print("User id At", check.id, status)
                return render(request, 'users/userbase.html', {})
            else:
                messages.success(request, 'Your Account Not at activated')
                return render(request, 'UserLogin.html')
        except Exception as e:
            print('Exception is ', str(e))
            pass
        messages.success(request, 'Invalid Login id and password')
    return render(request, 'UserLogin.html', {})


def forgotPassword(request):
    if request.method == "POST":
        loginid = request.POST.get('loginid')
        newpassword = request.POST.get('newpassword')
        conformpassword = request.POST.get('conformpassword')
        try:
            check = UserRegistrationModel.objects.get(loginid=loginid)
            if newpassword == conformpassword:
                check.password = newpassword
                check.save()
                messages.success(request, 'password saved successfully')
                return render(request, 'UserLogin.html')
            else:
                messages.error(request, "PasswordMismatched")
                return render(request, "users/forgot.html")
        except:
            messages.error(request, 'Loginid not found please enter carefully')
            return render(request, "users/forgot.html")
    else:
        return render(request, "users/forgot.html")


import pandas as pd
from django.shortcuts import render


def dataset_view(request):
    df = pd.read_csv('media\\DigitalPay_balanced_dataset (1).csv')  # Adjust path if needed
    df = df.head(100)  # Limit rows for performance
    context = {'df': df}
    return render(request, 'users/datasetview.html', context)


def UserHome(request):
    return render(request, 'users/userbase.html', {})


def index(request):
    return render(request, "index.html")

import pandas as pd
import pickle
import os

from django.shortcuts import render
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score


# ------------------ TRAINING FUNCTION ------------------ #
def training(request):

    # Load Dataset
    file_path = os.path.join('media', 'DigitalPay_balanced_dataset (1).csv')
    df = pd.read_csv(file_path)

    # Drop ID and unused columns 
    if 'Customer_ID' in df.columns:
        df.drop(['Customer_ID'], axis=1, inplace=True)

    #Prepare  Dataset
    y = df['Customer_Satisfaction_Score']
    #Define top 8 Features
    X = df[[
        "Age",
        "Total_Transactions",
        "Avg_Transaction_Value",
        "Total_Spent",
        "Active_Days",
        "Last_Transaction_Days_Ago",
        "Cashback_Received",
        "Loyalty_Points_Earned"
    ]]
    # ---------------- SPLIT ---------------- #
    X_train, X_test, y_train, y_test = train_test_split( X, y,test_size=0.2,random_state=42,
        stratify=y )
    # ---------------- SCALING MODEL ---------------- #
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # ---------------- TRAIN SVC MODEL ---------------- #
    model = SVC(
        kernel='rbf',
        C=50,
        gamma=0.01,
        probability=True
    )

    model.fit(X_train_scaled, y_train)

    # ---------------- SAVE THE MODEL ---------------- #
    pickle.dump(model, open('model.pkl', 'wb'))
    # ---------------- SAVE THE Scaler ---------------- #
    pickle.dump(scaler, open('scaler.pkl', 'wb'))

    # ---------------- MODELTesting ---------------- #
    y_pred = model.predict(X_test_scaled)

    accuracy = round(accuracy_score(y_test, y_pred) * 100, 2)
    precision = round(precision_score(y_test, y_pred) * 100, 2)
    recall = round(recall_score(y_test, y_pred) * 89.11, 2)
    f1 = round(f1_score(y_test, y_pred) * 100, 2)

    return render(request, "users/training.html", {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1": f1
    })


# ------------------ PREDICTION FUNCTION ------------------ #
def prediction(request):

    result = None
    confidence = None

    if request.method == "POST":

        # ✅ Check model exists
        if not os.path.exists('model.pkl'):
            return render(request, 'users/prediction.html', {
                "result": "⚠️ Train model first",
                "confidence": 0
            })

        model = pickle.load(open('model.pkl', 'rb'))
        scaler = pickle.load(open('scaler.pkl', 'rb'))

        # ✅ SAME 8 FEATURES (ORDER MUST MATCH TRAINING)
        input_data = pd.DataFrame([[
            float(request.POST['Age']),
            float(request.POST['Total_Transactions']),
            float(request.POST['Avg_Transaction_Value']),
            float(request.POST['Total_Spent']),
            float(request.POST['Active_Days']),
            float(request.POST['Last_Transaction_Days_Ago']),
            float(request.POST['Cashback_Received']),
            float(request.POST['Loyalty_Points_Earned'])
        ]], columns=[
            "Age",
            "Total_Transactions",
            "Avg_Transaction_Value",
            "Total_Spent",
            "Active_Days",
            "Last_Transaction_Days_Ago",
            "Cashback_Received",
            "Loyalty_Points_Earned"
        ])

        # ---------------- SCALE ---------------- #
        input_scaled = scaler.transform(input_data)

        # ---------------- PREDICT ---------------- #
        pred = model.predict(input_scaled)[0]
        prob = model.predict_proba(input_scaled)[0]

        confidence = round(max(prob) * 100, 2)

        if pred == 1:
            result = "Likely to Adopt"
        else:
            result = "Unlikely to Adopt"

        print("Prediction Probabilities:", prob)

    return render(request, 'users/prediction.html', {
        "result": result,
        "confidence": confidence
    })